import { Component, Input } from "@angular/core";


export type Item = {
  feito: boolean;
  name: string;
}


@Component({
  selector:'add-item',
  templateUrl: './add-item.html',
  styleUrls: ['add-item.css']
})

export class AddItem{

  @Input()
  public items : Array<Item> = [];
  
  public tarefa = "";

  addTarefa(){
    this.items.push({
      name: this.tarefa,
      feito: false
    });
  }

}
