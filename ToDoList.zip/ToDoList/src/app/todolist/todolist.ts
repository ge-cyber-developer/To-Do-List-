import { Component } from '@angular/core';
import { ListContent } from '../list-content/list-content'

export type Item = {
  feito: boolean;
  name: string;
}


@Component({
  selector:'app-todolist',
  templateUrl:'./todolist.html',
  styleUrls: ['todolist.css'],
})




export class ToDoList {

  public tarefa = "";
  public items : Array<Item> = [
    { name: 'item1', feito: false },
    { name: 'item2', feito: false },
    { name: 'item3', feito: false },
  ];


  showTarefas(){
    console.log(this.items)
  }

  addTarefa(){
    this.items.push({
      name: this.tarefa,
      feito: false
    });
  }

}
