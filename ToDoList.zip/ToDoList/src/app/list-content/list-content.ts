import { Component, Input } from "@angular/core";


export type Item = {
  feito: boolean;
  name: string;
}



@Component({
  selector:'list-content',
  templateUrl: './list-content.html',
  styleUrls: ['list-content.css']
})

export class ListContent{
  @Input()
  items : Array<Item> = [];

  showTarefas(){
    console.log(this.items)
  }


  removeTarefa(itemASerDeletado: Object){

    this.items = this.items.filter((itemNoArray) => {
      if (itemNoArray != itemASerDeletado){
        return true
      }else {
        return false
      }
    })
  }
}
